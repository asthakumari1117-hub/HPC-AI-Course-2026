#include <stdio.h>

int main() {
    printf("1. Newline (\\n): Line 1\nLine 2\n");
    printf("2. Tab (\\t): Column1\tColumn2\n");
    printf("3. Carriage Return (\\r): Overwritten\rHello\n");
    printf("4. Backspace (\\b): ABC\bDEF\n");
    printf("5. Formfeed (\\f): Page1\fPage2\n");
    printf("6. Vertical Tab (\\v): Vertical\vTab\n");
    printf("7. Alert (\\a): Beep!\a\n");
    printf("8. Backslash (\\\\): \\ \n");
    printf("9. Single Quote (\\\'): \' \n");
    printf("10. Double Quote (\\\"): \" \n");
    printf("11. Null Character (\\0): String terminates here.\n");
    return 0;
}