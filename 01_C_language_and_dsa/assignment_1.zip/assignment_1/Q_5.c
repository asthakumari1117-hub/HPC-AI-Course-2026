#include <stdio.h>
#include <stdint.h>

// Efficient Structure (packed size without padding penalty)
typedef struct {
    uint32_t roll_no; // 4 bytes
    float cgpa;       // 4 bytes
    float marks;      // 4 bytes
    uint8_t age;      // 1 byte
    char grade;       // 1 byte
} EfficientStudent;

// Inefficient Structure (padded due to structure alignment)
typedef struct {
    char grade;
    double cgpa;
    uint8_t age;
    double marks;
    long long roll_no;
} InefficientStudent;

int main() {
    printf("Efficient Student Record Size: %lu bytes\n", sizeof(EfficientStudent));
    printf("Inefficient Student Record Size: %lu bytes\n", sizeof(InefficientStudent));
    printf("Memory Saved per record: %lu bytes\n", sizeof(InefficientStudent) - sizeof(EfficientStudent));
    return 0;
}