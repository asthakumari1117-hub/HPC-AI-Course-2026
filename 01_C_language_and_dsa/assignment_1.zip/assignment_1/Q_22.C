#include <stdio.h>

int main() {
    int i = 42;
    unsigned int u = 100;
    double d = 3.14159265;
    char s[] = "Hello";

    printf("Integer Specifiers : %%d=%d, %%o=%o, %%x=%x, %%X=%X\n", i, i, i, i);
    printf("Unsigned Specifier : %%u=%u\n", u);
    printf("Float/Double       : %%f=%.2f, %%e=%e, %%g=%g\n", d, d, d);
    printf("String/Character   : %%s=%s, %%c=%c\n", s, s[0]);
    printf("Pointer Specifier  : %%p=%p\n", (void*)&i);
    return 0;
}