#include <stdio.h>

int main() {
    printf("=========================================\n");
    printf("|          STUDENT MARKSHEET            |\n");
    printf("=========================================\n");
    printf("| %-15s | %-10s | %-6s |\n", "Subject", "Max Marks", "Marks");
    printf("-----------------------------------------\n");
    printf("| %-15s | %-10d | %-6.2f |\n", "Mathematics", 100, 92.50);
    printf("| %-15s | %-10d | %-6.2f |\n", "Physics", 100, 88.00);
    printf("| %-15s | %-10d | %-6.2f |\n", "Computer Sci", 100, 98.25);
    printf("=========================================\n");
    return 0;
}