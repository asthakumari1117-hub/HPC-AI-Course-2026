#include <stdio.h>

int main() {
    double ram_gb;
    printf("Enter RAM size in GB: ");
    if (scanf("%lf", &ram_gb) != 1) return 1;

    double bytes = ram_gb * 1024 * 1024 * 1024;
    printf("Total Memory: %.0f Bytes\n\n", bytes);
    printf("char variables      : %.0f\n", bytes / sizeof(char));
    printf("short variables     : %.0f\n", bytes / sizeof(short));
    printf("int variables       : %.0f\n", bytes / sizeof(int));
    printf("long long variables : %.0f\n", bytes / sizeof(long long));
    printf("float variables     : %.0f\n", bytes / sizeof(float));
    printf("double variables    : %.0f\n", bytes / sizeof(double));
    return 0;
}