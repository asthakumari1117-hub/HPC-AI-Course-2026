#include <stdio.h>
#include <ctype.h>

int main() {
    int chars = 0, words = 0, lines = 0, digits = 0, alphabets = 0, vowels = 0, spaces = 0, special = 0;
    int in_word = 0, c;

    printf("Enter paragraph (terminate with ~ on a new line):\n");
    while ((c = getchar()) != '~' && c != EOF) {
        chars++;
        if (c == '\n') lines++;
        if (isalpha(c)) {
            alphabets++;
            char lower = tolower(c);
            if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u') vowels++;
        } else if (isdigit(c)) digits++;
        else if (isspace(c)) spaces++;
        else special++;

        if (isspace(c)) in_word = 0;
        else if (!in_word) { in_word = 1; words++; }
    }

    printf("\n--- Text Statistics ---\n");
    printf("Characters: %d | Words: %d | Lines: %d\n", chars, words, lines);
    printf("Alphabets: %d | Vowels: %d | Digits: %d\n", alphabets, vowels, digits);
    printf("Whitespace: %d | Special Symbols: %d\n", spaces, special);
    return 0;
}