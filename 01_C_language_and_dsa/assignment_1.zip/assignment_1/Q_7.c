#include <stdio.h>

int main() {
    printf("100U   -> Size: %lu bytes\n", sizeof(100U));
    printf("100L   -> Size: %lu bytes\n", sizeof(100L));
    printf("100LL  -> Size: %lu bytes\n", sizeof(100LL));
    printf("100UL  -> Size: %lu bytes\n", sizeof(100UL));
    printf("100ULL -> Size: %lu bytes\n", sizeof(100ULL));
    printf("3.14F  -> Size: %lu bytes\n", sizeof(3.14F));
    printf("3.14L  -> Size: %lu bytes\n", sizeof(3.14L));
    return 0;
}