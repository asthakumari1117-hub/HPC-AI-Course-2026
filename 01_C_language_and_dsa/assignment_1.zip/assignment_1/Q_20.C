#include <stdio.h>
#include <string.h>

#define MAX_NOTES 10
#define NOTE_LEN 200

int main() {
    char notes[MAX_NOTES][NOTE_LEN];
    int count = 0, choice;

    while (1) {
        printf("\n--- Note App ---\n1. Add Note\n2. Display Notes\n3. Search\n4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        getchar();

        if (choice == 1) {
            if (count < MAX_NOTES) {
                printf("Enter note: ");
                fgets(notes[count], NOTE_LEN, stdin);
                notes[count][strcspn(notes[count], "\n")] = 0;
                count++;
            } else printf("Storage full!\n");
        } else if (choice == 2) {
            for (int i = 0; i < count; i++) printf("[%d] %s\n", i + 1, notes[i]);
        } else if (choice == 3) {
            char query[50];
            printf("Search term: ");
            fgets(query, 50, stdin);
            query[strcspn(query, "\n")] = 0;
            for (int i = 0; i < count; i++) {
                if (strstr(notes[i], query)) printf("Found in [%d]: %s\n", i + 1, notes[i]);
            }
        } else break;
    }
    return 0;
}