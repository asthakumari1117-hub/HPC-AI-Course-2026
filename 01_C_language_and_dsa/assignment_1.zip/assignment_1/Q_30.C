#include <stdio.h>
#include <string.h>

void print_binary(unsigned char byte) {
    for (int i = 7; i >= 0; i--) printf("%d", (byte >> i) & 1);
}

void print_buffer(const char* label, unsigned char* buf, size_t len) {
    printf("\n--- %s ---\n", label);
    printf("Dec: ");
    for (size_t i = 0; i < len; i++) printf("%3d ", buf[i]);
    printf("\nHex: ");
    for (size_t i = 0; i < len; i++) printf(" 0x%02X ", buf[i]);
    printf("\nBin: ");
    for (size_t i = 0; i < len; i++) { print_binary(buf[i]); printf(" "); }
    printf("\n");
}

int main() {
    unsigned char arr1[5] = {1, 2, 3, 4, 5};
    unsigned char arr2[5] = {0};

    print_buffer("Initial arr1", arr1, 5);

    // memset operation
    memset(arr2, 0xFF, 5);
    print_buffer("arr2 after memset(0xFF)", arr2, 5);

    // memcpy operation
    memcpy(arr2, arr1, 5);
    print_buffer("arr2 after memcpy(arr1)", arr2, 5);

    // memcmp operation
    int diff = memcmp(arr1, arr2, 5);
    printf("\nmemcmp(arr1, arr2) result: %d (Identical)\n", diff);

    return 0;
}