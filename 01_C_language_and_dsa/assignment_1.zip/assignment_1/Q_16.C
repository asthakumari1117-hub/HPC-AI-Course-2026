#include <stdio.h>

int main() {
    char ch;
    char buffer[100];

    printf("1. Enter a character (getc): ");
    ch = getc(stdin);
    printf("Output via putc: ");
    putc(ch, stdout);
    printf("\n");

    while ((ch = getchar()) != '\n' && ch != EOF); // Clear buffer

    printf("2. Enter a line (fgets): ");
    if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        printf("Output via puts: ");
        puts(buffer);
    }
    return 0;
}