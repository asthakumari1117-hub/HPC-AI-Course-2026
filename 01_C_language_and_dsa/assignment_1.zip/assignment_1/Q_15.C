#include <stdio.h>

int main() {
    int octal_val, hex_val;
    printf("Enter octal escape value (e.g. 101 for 'A'): ");
    if (scanf("%o", &octal_val) != 1) return 1;
    printf("Octal Input -> Dec: %d, Hex: 0x%X, Char: %c\n", octal_val, octal_val, (char)octal_val);

    printf("Enter hex escape value (e.g. 41 for 'A'): ");
    if (scanf("%x", &hex_val) != 1) return 1;
    printf("Hex Input   -> Dec: %d, Hex: 0x%X, Char: %c\n", hex_val, hex_val, (char)hex_val);

    return 0;
}