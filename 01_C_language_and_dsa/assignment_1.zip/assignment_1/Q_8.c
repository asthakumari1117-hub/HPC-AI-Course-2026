#include <stdio.h>

void to_octal(int n) {
    if (n == 0) { printf("0"); return; }
    int oct[32], i = 0;
    while (n > 0) { oct[i++] = n % 8; n /= 8; }
    for (int j = i - 1; j >= 0; j--) printf("%d", oct[j]);
}

void to_hex(int n) {
    if (n == 0) { printf("0"); return; }
    char hex[32]; int i = 0;
    while (n > 0) {
        int rem = n % 16;
        hex[i++] = (rem < 10) ? (rem + '0') : (rem - 10 + 'A');
        n /= 16;
    }
    for (int j = i - 1; j >= 0; j--) printf("%c", hex[j]);
}

int main() {
    int num;
    printf("Enter a decimal number: ");
    if (scanf("%d", &num) != 1) return 1;

    printf("Octal       : "); to_octal(num); printf("\n");
    printf("Hexadecimal : "); to_hex(num); printf("\n");
    return 0;
}