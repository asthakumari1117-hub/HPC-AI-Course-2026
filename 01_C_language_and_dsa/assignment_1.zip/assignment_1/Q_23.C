#include <stdio.h>

int main() {
    char name[50] = "John Doe";
    double basic = 50000.0, hra = 15000.0, da = 10000.0;
    double tax = 5000.0, pf = 3000.0;
    double gross = basic + hra + da;
    double deductions = tax + pf;
    double net = gross - deductions;

    printf("=========================================\n");
    printf("          EMPLOYEE SALARY REPORT         \n");
    printf("=========================================\n");
    printf("Employee Name: %s\n", name);
    printf("-----------------------------------------\n");
    printf("%-20s : $%-10.2f\n", "Basic Salary", basic);
    printf("%-20s : $%-10.2f\n", "HRA", hra);
    printf("%-20s : $%-10.2f\n", "DA", da);
    printf("%-20s : $%-10.2f\n", "Gross Salary", gross);
    printf("-----------------------------------------\n");
    printf("%-20s : $%-10.2f\n", "Tax Deduction", tax);
    printf("%-20s : $%-10.2f\n", "PF Deduction", pf);
    printf("%-20s : $%-10.2f\n", "Total Deductions", deductions);
    printf("=========================================\n");
    printf("%-20s : $%-10.2f\n", "NET SALARY", net);
    printf("=========================================\n");
    return 0;
}