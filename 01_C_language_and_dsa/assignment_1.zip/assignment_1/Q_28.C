#include <stdio.h>
#include <string.h>

int main() {
    char b1[] = "Hello World";
    char b2[] = "Hello C World";

    int res = memcmp(b1, b2, sizeof(b1));
    if (res == 0) {
        printf("Memory blocks are identical.\n");
    } else {
        printf("Memory blocks differ!\n");
        for (size_t i = 0; i < sizeof(b1); i++) {
            if (b1[i] != b2[i]) {
                printf("First mismatch at byte index %lu: b1='%-c' (0x%02X), b2='%-c' (0x%02X)\n",
                       i, b1[i], (unsigned char)b1[i], b2[i], (unsigned char)b2[i]);
                break;
            }
        }
    }
    return 0;
}