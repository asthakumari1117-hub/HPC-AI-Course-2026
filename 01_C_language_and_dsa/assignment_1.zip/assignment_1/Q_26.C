#include <stdio.h>
#include <string.h>

int main() {
    char str1[20] = "1234567890";
    char str2[20] = "1234567890";

    printf("Original String: 1234567890\n");

    // Overlapping regions: memmove safely handles overlapping memory
    memmove(str1 + 2, str1, 5);
    printf("After memmove (str+2, str, 5): %s\n", str1);

    // memcpy behavior on overlapping buffers is undefined
    memcpy(str2 + 2, str2, 5);
    printf("After memcpy  (str+2, str, 5): %s\n", str2);
    return 0;
}