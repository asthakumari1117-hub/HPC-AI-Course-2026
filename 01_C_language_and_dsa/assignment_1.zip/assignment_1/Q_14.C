#include <stdio.h>

int main() {
    printf("--- Tabular Pattern ---\n");
    printf("ID\tNAME\t\tSCORE\n");
    printf("01\tAlice\t\t95.5\n");
    printf("02\tBob\t\t88.0\n\n");

    printf("--- Geometric Pattern (Triangle) ---\n");
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5 - i; j++) printf(" ");
        for (int k = 1; k <= (2 * i - 1); k++) printf("*");
        printf("\n");
    }
    return 0;
}