#include <stdio.h>

int main() {
    char item[30] = "Laptop";
    int qty = 2;
    double price = 750.00;
    double subtotal = qty * price;
    double gst = subtotal * 0.18;
    double grand_total = subtotal + gst;

    printf("===================================================\n");
    printf("                  INVOICE BILL                    \n");
    printf("===================================================\n");
    printf("%-20s %-10s %-10s %-10s\n", "Item", "Qty", "Price", "Total");
    printf("---------------------------------------------------\n");
    printf("%-20s %-10d $%-9.2f $%-9.2f\n", item, qty, price, subtotal);
    printf("---------------------------------------------------\n");
    printf("%30s Subtotal   : $%.2f\n", "", subtotal);
    printf("%30s GST (18%%)  : $%.2f\n", "", gst);
    printf("===================================================\n");
    printf("%30s GRAND TOTAL: $%.2f\n", "", grand_total);
    printf("===================================================\n");
    return 0;
}