#include <stdio.h>

int main() {
    int num = 42;
    double pi = 3.14159;

    printf("1. Right Alignment (width 10): '%10d'\n", num);
    printf("2. Left Alignment (width 10) : '%-10d'\n", num);
    printf("3. Zero Padding (width 10)   : '%010d'\n", num);
    printf("4. Always Show Sign (+)      : '%+d'\n", num);
    printf("5. Space Flag                : '% d'\n", num);
    printf("6. Precision (.2f)           : '%.2f'\n", pi);
    printf("7. Alternate Form (# Hex)    : '%#x'\n", num);
    return 0;
}