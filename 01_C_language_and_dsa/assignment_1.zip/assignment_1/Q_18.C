#include <stdio.h>

int main() {
    printf("Line buffering test (flushed explicitly)... ");
    fflush(stdout); // Forces output immediately without waiting for newline

    printf("\nType a line and press Enter: ");
    char c = getchar();
    printf("First character read from buffer: %c\n", c);
    return 0;
}