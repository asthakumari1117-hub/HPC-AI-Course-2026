#include <stdio.h>
#include <limits.h>

int main() {
    printf("Type\t\tSize (bytes)\tMin Value\t\tMax Value\n");
    printf("-----------------------------------------------------------------------\n");
    printf("char\t\t%lu\t\t%d\t\t\t%d\n", sizeof(char), CHAR_MIN, CHAR_MAX);
    printf("short\t\t%lu\t\t%d\t\t\t%d\n", sizeof(short), SHRT_MIN, SHRT_MAX);
    printf("int\t\t%lu\t\t%d\t\t%d\n", sizeof(int), INT_MIN, INT_MAX);
    printf("long\t\t%lu\t\t%ld\t%ld\n", sizeof(long), LONG_MIN, LONG_MAX);
    printf("long long\t%lu\t\t%lld\t%lld\n", sizeof(long long), LLONG_MIN, LLONG_MAX);
    return 0;
}