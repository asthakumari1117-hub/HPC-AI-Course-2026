#include <stdio.h>

int main() {
    int c, prev_was_space = 0, prev_was_newline = 0;
    printf("Enter text (press Ctrl+D or Ctrl+Z to finish):\n");

    while ((c = getchar()) != EOF) {
        if (c == '\r') continue;
        if (c == ' ' || c == '\t') {
            if (!prev_was_space && !prev_was_newline) {
                putchar(' ');
                prev_was_space = 1;
            }
        } else if (c == '\n') {
            if (!prev_was_newline) {
                putchar('\n');
                prev_was_newline = 1;
            }
            prev_was_space = 0;
        } else {
            putchar(c);
            prev_was_space = 0;
            prev_was_newline = 0;
        }
    }
    return 0;
}