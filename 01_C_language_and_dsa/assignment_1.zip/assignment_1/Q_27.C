#include <stdio.h>

void* custom_memcpy(void* dest, const void* src, size_t n) {
    char* d = (char*)dest;
    const char* s = (const char*)src;
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

int main() {
    char src[] = "Custom Memcpy Implementation";
    char dest[50];

    custom_memcpy(dest, src, sizeof(src));
    printf("Source : %s\n", src);
    printf("Copied : %s\n", dest);
    return 0;
}