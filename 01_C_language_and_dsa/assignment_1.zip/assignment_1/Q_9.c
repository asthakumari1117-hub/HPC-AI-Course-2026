#include <stdio.h>
#include <math.h>

int main() {
    double a, b;
    char op;
    printf("Enter expression (e.g., 2.5e2 + 1.2e1): ");
    if (scanf("%lf %c %lf", &a, &op, &b) != 3) return 1;

    switch (op) {
        case '+': printf("Result: %e (Standard: %f)\n", a + b, a + b); break;
        case '-': printf("Result: %e (Standard: %f)\n", a - b, a - b); break;
        case '*': printf("Result: %e (Standard: %f)\n", a * b, a * b); break;
        case '/': 
            if (b != 0) printf("Result: %e (Standard: %f)\n", a / b, a / b);
            else printf("Error: Division by zero\n");
            break;
        case '^': printf("Result: %e (Standard: %f)\n", pow(a, b), pow(a, b)); break;
        default: printf("Invalid operator\n");
    }
    return 0;
}