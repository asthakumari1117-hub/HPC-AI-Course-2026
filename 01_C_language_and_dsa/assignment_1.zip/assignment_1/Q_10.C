#include <stdio.h>
#include <limits.h>

int main() {
    long long val;
    printf("Enter an integer value: ");
    if (scanf("%lld", &val) != 1) return 1;

    printf("\nSafe storage check for %lld:\n", val);
    printf("char      : %s\n", (val >= SCHAR_MIN && val <= SCHAR_MAX) ? "YES" : "NO (Overflow)");
    printf("short     : %s\n", (val >= SHRT_MIN && val <= SHRT_MAX) ? "YES" : "NO (Overflow)");
    printf("int       : %s\n", (val >= INT_MIN && val <= INT_MAX) ? "YES" : "NO (Overflow)");
    printf("long      : %s\n", (val >= LONG_MIN && val <= LONG_MAX) ? "YES" : "NO (Overflow)");
    printf("long long : YES\n");
    return 0;
}