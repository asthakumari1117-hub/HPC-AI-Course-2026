#include <stdio.h>
#include <ctype.h>

int main() {
    char ch;
    printf("Enter a character: ");
    if (scanf("%c", &ch) != 1) return 1;

    if (isupper(ch)) printf("Uppercase Alphabet\n");
    else if (islower(ch)) printf("Lowercase Alphabet\n");
    else if (isdigit(ch)) printf("Digit\n");
    else if (ispunct(ch)) printf("Punctuation Mark\n");
    else if (isspace(ch)) printf("Whitespace Character\n");
    else printf("Special Symbol\n");

    return 0;
}