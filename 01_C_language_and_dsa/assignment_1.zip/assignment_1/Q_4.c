#include <stdio.h>

int main() {
    printf("Pointer size: %lu bytes\n", sizeof(void*));
    if (sizeof(void*) == 8) {
        printf("Architecture: 64-bit System\n\n");
    } else if (sizeof(void*) == 4) {
        printf("Architecture: 32-bit System\n\n");
    }

    printf("Primitive Type Sizes:\n");
    printf("char: %lu | short: %lu | int: %lu | long: %lu | float: %lu | double: %lu\n",
           sizeof(char), sizeof(short), sizeof(int), sizeof(long), sizeof(float), sizeof(double));
    return 0;
}