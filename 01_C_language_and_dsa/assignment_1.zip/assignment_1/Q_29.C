#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int size = 5;
    int* arr = (int*)malloc(size * sizeof(int));
    if (!arr) return 1;

    // Initialize memory region to zero
    memset(arr, 0, size * sizeof(int));

    printf("Contents after memset(0):\n");
    for (int i = 0; i < size; i++) printf("arr[%d] = %d\n", i, arr[i]);

    // Modify specific elements
    arr[1] = 100;
    arr[3] = 300;

    printf("\nContents after modification:\n");
    for (int i = 0; i < size; i++) printf("arr[%d] = %d\n", i, arr[i]);

    free(arr);
    return 0;
}