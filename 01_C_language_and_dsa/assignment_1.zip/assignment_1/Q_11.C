#include <stdio.h>

int main() {
    printf("Dec\tHex\tOct\tChar\n");
    printf("-----------------------------\n");
    for (int i = 0; i < 128; i++) {
        if (i < 32 || i == 127) {
            printf("%d\t0x%02X\t0%03o\t[Non-printable]\n", i, i, i);
        } else {
            printf("%d\t0x%02X\t0%03o\t%c\n", i, i, i, i);
        }
    }
    return 0;
}