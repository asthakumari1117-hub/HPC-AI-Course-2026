#include <stdio.h>

int main() {
    float f = 1.0f / 3.0f;
    double d = 1.0 / 3.0;
    long double ld = 1.0L / 3.0L;

    printf("Float (6 decimal precision):      %.6f\n", f);
    printf("Float (20 decimal precision):     %.20f\n", f);
    printf("Double (15 decimal precision):    %.15lf\n", d);
    printf("Double (20 decimal precision):    %.20lf\n", d);
    printf("Long Double (20 dec precision):  %.20Lf\n", ld);
    return 0;
}