#include <stdio.h>

int main() {
    int dec = 42;
    int oct = 052;
    int hex = 0x2A;
    double hex_float = 0x1.5p3; // 1.3125 * 2^3 = 10.5

    printf("Decimal Constant 42        = %d\n", dec);
    printf("Octal Constant 052         = %d\n", oct);
    printf("Hex Constant 0x2A          = %d\n", hex);
    printf("Hex Float Constant 0x1.5p3 = %f\n", hex_float);
    return 0;
}