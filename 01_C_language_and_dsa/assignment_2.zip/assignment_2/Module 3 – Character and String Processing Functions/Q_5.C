#include <stdio.h>
#include <string.h>

int main() {
    char source[] = "Standard C Library";
    char destination[50];

    strcpy(destination, source);
    printf("Copied String: %s\n", destination);

    return 0;
}