#include <stdio.h>
#include <ctype.h>

int main() {
    char str[] = "Hello World 2026";

    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = (char)tolower((unsigned char)str[i]);
    }

    printf("Lowercase: %s\n", str);
    return 0;
}