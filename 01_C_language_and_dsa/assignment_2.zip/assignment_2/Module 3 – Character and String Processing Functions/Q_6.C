#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "Find character in string";
    char ch = 'c';

    char *ptr = strchr(str, ch);

    if (ptr) printf("First occurrence of '%c' found at index %ld.\n", ch, ptr - str);
    else printf("Character not found.\n");

    return 0;
}