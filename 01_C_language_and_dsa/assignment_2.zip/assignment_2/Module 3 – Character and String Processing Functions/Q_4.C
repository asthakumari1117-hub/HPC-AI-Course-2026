#include <stdio.h>
#include <string.h>

int main() {
    char str1[] = "Apple";
    char str2[] = "Banana";

    int res = strcmp(str1, str2);

    if (res == 0) printf("Strings are identical.\n");
    else if (res < 0) printf("\"%s\" comes before \"%s\".\n", str1, str2);
    else printf("\"%s\" comes after \"%s\".\n", str1, str2);

    return 0;
}