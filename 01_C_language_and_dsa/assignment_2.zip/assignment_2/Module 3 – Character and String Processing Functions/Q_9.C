#include <stdio.h>
#include <stdlib.h>

int main() {
    char numStr[] = "25";
    int val = atoi(numStr);

    printf("Converted Integer: %d\n", val);
    printf("Square: %d\n", val * val);

    return 0;
}