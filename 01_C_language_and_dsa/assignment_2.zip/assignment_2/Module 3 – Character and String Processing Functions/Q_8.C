#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "Extracting individual words using strtok function";
    const char *delim = " ";

    char *token = strtok(str, delim);
    while (token != NULL) {
        printf("Word: %s\n", token);
        token = strtok(NULL, delim);
    }

    return 0;
}