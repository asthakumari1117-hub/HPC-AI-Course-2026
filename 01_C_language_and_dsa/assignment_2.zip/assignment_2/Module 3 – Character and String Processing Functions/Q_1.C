#include <stdio.h>
#include <ctype.h>

int main() {
    char str[] = "Code123!@#";
    int alpha = 0, digit = 0, special = 0;

    for (int i = 0; str[i] != '\0'; i++) {
        if (isalpha((unsigned char)str[i])) alpha++;
        else if (isdigit((unsigned char)str[i])) digit++;
        else special++;
    }

    printf("Alphabets: %d | Digits: %d | Special: %d\n", alpha, digit, special);
    return 0;
}