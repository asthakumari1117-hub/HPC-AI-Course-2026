#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "Find character in string";
    char ch = 'i';

    char *ptr = strrchr(str, ch);

    if (ptr) printf("Last occurrence of '%c' found at index %ld.\n", ch, ptr - str);
    else printf("Character not found.\n");

    return 0;
}