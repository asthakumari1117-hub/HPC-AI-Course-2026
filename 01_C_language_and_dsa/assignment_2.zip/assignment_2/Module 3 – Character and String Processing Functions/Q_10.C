#include <stdio.h>
#include <ctype.h>

int main() {
    char text[] = "Analyzer test 123: counts vowels & spaces!";
    int chars = 0, words = 0, vowels = 0, digits = 0, spaces = 0;
    int inWord = 0;

    for (int i = 0; text[i] != '\0'; i++) {
        char ch = text[i];
        chars++;

        if (isdigit((unsigned char)ch)) digits++;
        if (isspace((unsigned char)ch)) spaces++;

        char low = (char)tolower((unsigned char)ch);
        if (low == 'a' || low == 'e' || low == 'i' || low == 'o' || low == 'u') {
            vowels++;
        }

        if (!isspace((unsigned char)ch)) {
            if (!inWord) {
                inWord = 1;
                words++;
            }
        } else {
            inWord = 0;
        }
    }

    printf("Total Chars : %d\nWords       : %d\nVowels      : %d\nDigits      : %d\nSpaces      : %d\n",
           chars, words, vowels, digits, spaces);
    return 0;
}