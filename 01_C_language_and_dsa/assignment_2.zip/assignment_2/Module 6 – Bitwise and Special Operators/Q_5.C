
#include <stdio.h>

int main() {
    int x = 2, y = 4;

    printf("Logical AND  (x && y) : %d (evaluates truth values)\n", x && y);
    printf("Bitwise AND  (x & y)  : %d (evaluates bits: 0010 & 0100 = 0000)\n", x & y);

    return 0;
}