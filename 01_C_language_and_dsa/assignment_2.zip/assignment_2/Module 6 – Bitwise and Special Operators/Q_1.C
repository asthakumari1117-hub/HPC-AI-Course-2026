#include <stdio.h>

int main() {
    unsigned int a = 12; // 0000 1100
    unsigned int b = 5;  // 0000 0101

    printf("Bitwise AND (a & b)  : %u\n", a & b);
    printf("Bitwise OR  (a | b)  : %u\n", a | b);
    printf("Bitwise XOR (a ^ b)  : %u\n", a ^ b);
    printf("Bitwise NOT (~a)     : %u\n", ~a);
    printf("Left Shift  (a << 1) : %u\n", a << 1);
    printf("Right Shift (a >> 1) : %u\n", a >> 1);

    return 0;
}