#include <stdio.h>

int main() {
    int num = 7;

    printf("Original : %d\n", num);
    printf("x 2 (<<1): %d\n", num << 1);
    printf("x 4 (<<2): %d\n", num << 2);
    printf("x 8 (<<3): %d\n", num << 3);

    return 0;
}