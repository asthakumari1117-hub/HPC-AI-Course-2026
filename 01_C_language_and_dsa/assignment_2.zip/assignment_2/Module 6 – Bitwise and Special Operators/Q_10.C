#include <stdio.h>

int main() {
    int n = 12;

    printf("Number: %d\n", n);
    printf("Is Even?            : %s\n", (n % 2 == 0) ? "Yes" : "No");
    printf("Is Positive & > 10? : %s\n", (n > 0 && n > 10) ? "Yes" : "No");
    printf("Bitwise AND with 1  : %d (0 means even)\n", n & 1);

    return 0;
}