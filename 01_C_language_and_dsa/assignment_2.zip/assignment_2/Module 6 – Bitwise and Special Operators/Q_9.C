#include <stdio.h>

int main() {
    int a = 10, b = 4;

    double implicitRes = a; // Implicit
    double explicitRes = (double)a / b; // Explicit

    printf("Implicit: %.2f\n", implicitRes);
    printf("Explicit: %.2f\n", explicitRes);

    return 0;
}