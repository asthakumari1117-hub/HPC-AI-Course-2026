#include <stdio.h>

int main() {
    int num = 64;

    printf("Original : %d\n", num);
    printf("/ 2 (>>1): %d\n", num >> 1);
    printf("/ 4 (>>2): %d\n", num >> 2);
    printf("/ 8 (>>3): %d\n", num >> 3);

    return 0;
}