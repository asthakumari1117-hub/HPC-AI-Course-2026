#include <stdio.h>

void printBinary(int num) {
    for (int i = 31; i >= 0; i--) {
        int k = num >> i;
        if (k & 1) printf("1");
        else printf("0");
    }
    printf("\n");
}

int main() {
    int val = 29;
    printf("Binary of %d: ", val);
    printBinary(val);
    return 0;
}