#include <stdio.h>

int main() {
    int a, b, result;

    // Evaluates left to right, returning value of last expression
    result = (a = 5, b = 10, a + b);

    printf("a: %d, b: %d, result: %d\n", a, b, result);
    return 0;
}