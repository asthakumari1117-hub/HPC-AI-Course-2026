#include <stdio.h>

int main() {
    char ch = 'A';

    printf("Character: %c\n", ch);
    printf("ASCII (Promoted to int): %d\n", ch);

    return 0;
}