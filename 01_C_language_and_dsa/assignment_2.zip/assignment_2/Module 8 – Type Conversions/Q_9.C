#include <stdio.h>

int main() {
    short s = -100;
    int i = s;           // Sign and value preserved
    unsigned int u = s;  // Value changes due to unsigned conversion

    printf("Short: %d | Int: %d | Unsigned Int: %u\n", s, i, u);
    return 0;
}