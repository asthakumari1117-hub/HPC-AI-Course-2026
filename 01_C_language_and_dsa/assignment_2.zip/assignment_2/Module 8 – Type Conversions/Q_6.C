#include <stdio.h>

int main() {
    int asciiCode = 67;
    char ch = (char)asciiCode;

    printf("ASCII Code %d corresponds to character: '%c'\n", asciiCode, ch);
    return 0;
}