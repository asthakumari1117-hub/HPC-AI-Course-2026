#include <stdio.h>

int main() {
    int a = 15;
    float b = 4.2f;
    double c = 8.99;

    printf("=== Type Conversion Analyzer ===\n");
    printf("Implicit (int + float) : %f\n", a + b);
    printf("Explicit (int / (int)b): %d\n", a / (int)b);
    printf("Double to Int          : %d\n", (int)c);
    printf("Int to Char ASCII      : %c\n", (char)(a + 50));

    return 0;
}