#include <stdio.h>

int main() {
    int s = -10;
    unsigned int u = 5;

    // 's' gets converted to unsigned int, making -10 a very large positive number!
    if (s < u) {
        printf("Signed comparison: -10 < 5\n");
    } else {
        printf("Unsigned conversion happened: -10 is treated as > 5\n");
    }

    return 0;
}