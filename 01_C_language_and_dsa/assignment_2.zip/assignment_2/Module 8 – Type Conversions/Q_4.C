#include <stdio.h>

int main() {
    float pi = 3.14159f;
    int truncatedPi = (int)pi;

    printf("Float value : %.5f\n", pi);
    printf("Explicit int: %d\n", truncatedPi);

    return 0;
}