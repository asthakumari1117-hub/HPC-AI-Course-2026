#include <stdio.h>

int main() {
    char a = 100, b = 50;

    // a and b are promoted to int before addition
    int result = a + b;

    printf("Result: %d (Size: %lu bytes)\n", result, sizeof(a + b));
    return 0;
}