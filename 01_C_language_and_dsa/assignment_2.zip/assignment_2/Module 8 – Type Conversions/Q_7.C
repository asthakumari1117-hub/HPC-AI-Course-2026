#include <stdio.h>

int main() {
    int signedVal = -5;
    unsigned int unsignedVal = (unsigned int)signedVal;

    printf("Signed int   : %d\n", signedVal);
    printf("Unsigned int : %u\n", unsignedVal);

    return 0;
}