#include <stdio.h>

int main() {
    int i = 7;
    float f = 2.5f;

    float result = i + f; // i implicitly converted to float
    printf("Result of %d + %.2f = %.2f\n", i, f, result);

    return 0;
}