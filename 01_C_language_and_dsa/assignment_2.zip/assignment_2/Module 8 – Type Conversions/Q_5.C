#include <stdio.h>

int main() {
    double d = 99.99;
    int converted = (int)d;

    printf("Double value   : %.2f\n", d);
    printf("Converted int  : %d (fractional part truncated)\n", converted);

    return 0;
}