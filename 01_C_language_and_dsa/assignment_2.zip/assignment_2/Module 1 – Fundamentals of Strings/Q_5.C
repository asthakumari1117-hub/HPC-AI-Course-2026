#include <stdio.h>

int main() {
    char str[] = "Hello World! 123 #2026";
    int upper = 0, lower = 0, digits = 0, special = 0;

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') upper++;
        else if (str[i] >= 'a' && str[i] <= 'z') lower++;
        else if (str[i] >= '0' && str[i] <= '9') digits++;
        else special++;
    }

    printf("Uppercase: %d\nLowercase: %d\nDigits: %d\nSpecial: %d\n", 
           upper, lower, digits, special);
    return 0;
}