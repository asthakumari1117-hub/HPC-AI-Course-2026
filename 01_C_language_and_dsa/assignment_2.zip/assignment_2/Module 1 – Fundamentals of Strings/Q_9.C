#include <stdio.h>

int main() {
    char s1[] = "Apple";
    char s2[] = "Apple";
    int i = 0, flag = 0;

    while (s1[i] != '\0' || s2[i] != '\0') {
        if (s1[i] != s2[i]) {
            flag = s1[i] - s2[i];
            break;
        }
        i++;
    }

    if (flag == 0) printf("Strings are equal.\n");
    else printf("Strings are not equal (difference: %d).\n", flag);

    return 0;
}