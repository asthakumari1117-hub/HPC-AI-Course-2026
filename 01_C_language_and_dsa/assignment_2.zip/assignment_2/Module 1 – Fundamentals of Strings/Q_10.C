#include <stdio.h>

int main() {
    char str[] = "C Programming Language 2026";

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == ' ') {
            str[i] = '_';
        }
    }

    printf("Modified string: %s\n", str);
    return 0;
}