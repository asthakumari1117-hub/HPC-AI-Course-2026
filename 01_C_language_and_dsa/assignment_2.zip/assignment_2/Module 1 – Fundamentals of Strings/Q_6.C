#include <stdio.h>

int main() {
    char src[] = "Copy This String";
    char dest[50];
    int i = 0;

    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';

    printf("Source: %s\nDestination: %s\n", src, dest);
    return 0;
}