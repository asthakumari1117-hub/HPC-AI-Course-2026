#include <stdio.h>
#include <string.h>

int main() {
    char str[50], maxStr[50] = "";
    int n;

    printf("Enter count of strings: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Enter string %d: ", i + 1);
        scanf("%49s", str);
        if (strlen(str) > strlen(maxStr)) {
            strcpy(maxStr, str);
        }
    }

    printf("Longest String: %s\n", maxStr);
    return 0;
}