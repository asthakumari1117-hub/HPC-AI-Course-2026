#include <stdio.h>

int main() {
    char ch;
    int lines = 0;

    printf("Enter text (type ~ to stop):\n");
    while ((ch = getchar()) != '~') {
        if (ch == '\n') lines++;
    }

    printf("Total lines entered: %d\n", lines);
    return 0;
}