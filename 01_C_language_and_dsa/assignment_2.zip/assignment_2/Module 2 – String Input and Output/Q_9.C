#include <stdio.h>
#include <string.h>

int main() {
    char names[10][50] = {
        "Liam", "Noah", "Oliver", "Elijah", "James",
        "William", "Benjamin", "Lucas", "Henry", "Alexander"
    };
    char target[50];
    int found = 0;

    printf("Enter name to search: ");
    scanf("%49s", target);

    for (int i = 0; i < 10; i++) {
        if (strcmp(names[i], target) == 0) {
            found = 1;
            break;
        }
    }

    if (found) printf("Name '%s' exists in the list.\n", target);
    else printf("Name '%s' not found.\n", target);

    return 0;
}