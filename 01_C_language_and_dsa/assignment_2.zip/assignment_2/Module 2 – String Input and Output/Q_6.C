#include <stdio.h>

struct Student {
    char name[50];
    int roll;
    char branch[20];
};

int main() {
    struct Student s = {"Alex Johnson", 101, "Computer Science"};

    printf("--- Student Record ---\n");
    printf("Name  : %s\n", s.name);
    printf("Roll  : %d\n", s.roll);
    printf("Branch: %s\n", s.branch);

    return 0;
}