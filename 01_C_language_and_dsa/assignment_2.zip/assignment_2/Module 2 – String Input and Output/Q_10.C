#include <stdio.h>

int main() {
    char contacts[3][2][50] = {
        {"Alice", "123-456-7890"},
        {"Bob", "987-654-3210"},
        {"Charlie", "555-666-7777"}
    };

    printf("--- Phone Contact List ---\n");
    for (int i = 0; i < 3; i++) {
        printf("Name: %-10s | Phone: %s\n", contacts[i][0], contacts[i][1]);
    }
    return 0;
}