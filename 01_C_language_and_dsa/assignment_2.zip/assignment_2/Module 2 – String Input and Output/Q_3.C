#include <stdio.h>

int main() {
    char students[5][50] = {
        "Alice", "Bob", "Charlie", "Diana", "Ethan"
    };

    printf("Student List:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d. %s\n", i + 1, students[i]);
    }
    return 0;
}