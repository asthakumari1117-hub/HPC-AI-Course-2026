#include <stdio.h>
#include <string.h>

int main() {
    char str[50], minStr[50];
    int n;

    printf("Enter count of strings: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Enter string %d: ", i + 1);
        scanf("%49s", str);
        if (i == 0 || strlen(str) < strlen(minStr)) {
            strcpy(minStr, str);
        }
    }

    printf("Shortest String: %s\n", minStr);
    return 0;
}