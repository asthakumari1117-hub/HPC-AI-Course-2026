#include <stdio.h>

int main() {
    char report[200];
    char name[] = "Sarah";
    int roll = 42;
    float gpa = 3.9;

    sprintf(report, "REPORT CARD -> Student: %s | Roll: %d | GPA: %.2f", name, roll, gpa);
    printf("%s\n", report);

    return 0;
}