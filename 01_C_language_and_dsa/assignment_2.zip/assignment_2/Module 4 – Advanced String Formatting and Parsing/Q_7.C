#include <stdio.h>

int main() {
    char buffer[10];
    
    // sprintf does not guard against buffer overflow (potential safety issue)
    // snprintf safely limits output size including null terminator
    
    int written = snprintf(buffer, sizeof(buffer), "1234567890ABCDEF");
    printf("Safely stored buffer content: %s\n", buffer);
    printf("Total characters that would have been written: %d\n", written);

    return 0;
}