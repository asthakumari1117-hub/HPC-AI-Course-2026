#include <stdio.h>

int main() {
    char empData[] = "E102,Mark,Manager,75000";
    char id[10], name[30], designation[30];
    double salary;

    sscanf(empData, "%[^,],%[^,],%[^,],%lf", id, name, designation, &salary);

    printf("ID          : %s\n", id);
    printf("Name        : %s\n", name);
    printf("Designation : %s\n", designation);
    printf("Salary      : $%.2f\n", salary);

    return 0;
}