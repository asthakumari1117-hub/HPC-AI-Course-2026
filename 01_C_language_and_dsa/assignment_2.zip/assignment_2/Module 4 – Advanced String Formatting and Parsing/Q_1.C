#include <stdio.h>

int main() {
    char info[] = "John 105 88.5";
    char name[30];
    int roll;
    float marks;

    sscanf(info, "%s %d %f", name, &roll, &marks);
    printf("Parsed Info: Name=%s, Roll=%d, Marks=%.2f\n", name, roll, marks);

    return 0;
}