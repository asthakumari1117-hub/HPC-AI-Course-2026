#include <stdio.h>

int main() {
    char payslip[300];
    char name[] = "Alice Smith";
    double basic = 50000.0, hra = 10000.0, da = 5000.0;
    double gross = basic + hra + da;

    sprintf(payslip, "=======================\nSALARY SLIP: %s\nBasic: $%.2f\nHRA  : $%.2f\nDA   : $%.2f\nGross: $%.2f\n=======================", 
            name, basic, hra, da, gross);

    printf("%s\n", payslip);
    return 0;
}