#include <stdio.h>

int main() {
    char reportCard[300];
    char student[] = "David";
    int math = 92, science = 88, english = 95;
    float avg = (math + science + english) / 3.0f;

    snprintf(reportCard, sizeof(reportCard),
             "Student Report Card\nName   : %s\nMath   : %d\nScience: %d\nEnglish: %d\nAverage: %.2f\nResult : PASS\n",
             student, math, science, english, avg);

    printf("%s", reportCard);
    return 0;
}