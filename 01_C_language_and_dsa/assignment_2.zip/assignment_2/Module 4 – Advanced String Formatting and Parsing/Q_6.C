#include <stdio.h>

int main() {
    char invoice[200];
    char item[] = "Wireless Mouse";
    int qty = 3;
    float price = 25.50;

    snprintf(invoice, sizeof(invoice), "INVOICE: %d x %s @ $%.2f = $%.2f", qty, item, price, qty * price);
    printf("%s\n", invoice);

    return 0;
}