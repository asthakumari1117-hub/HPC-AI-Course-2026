#include <stdio.h>
#include <string.h>

int main() {
    char csvRow[] = "Laptop,1200.00,5,Electronics";
    char *token = strtok(csvRow, ",");

    int col = 1;
    while (token != NULL) {
        printf("Column %d: %s\n", col++, token);
        token = strtok(NULL, ",");
    }

    return 0;
}