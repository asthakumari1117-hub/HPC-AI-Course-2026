#include <stdio.h>

int main() {
    char receipt[250];
    long accNum = 9876543210;
    double amount = 500.00;
    char type[] = "Deposit";

    snprintf(receipt, sizeof(receipt), 
             "--- BANK RECEIPT ---\nAccount : %ld\nType    : %s\nAmount  : $%.2f\nStatus  : SUCCESSFUL\n", 
             accNum, type, amount);

    printf("%s", receipt);
    return 0;
}