#include <stdio.h>

int main() {
    char bill[250];
    char prod[] = "Keyboard";
    int qty = 2;
    float unitPrice = 45.0;
    float tax = 0.10 * (qty * unitPrice);

    snprintf(bill, sizeof(bill), "ITEM: %s | QTY: %d | PRICE: $%.2f | TAX: $%.2f | TOTAL: $%.2f",
             prod, qty, unitPrice, tax, (qty * unitPrice) + tax);

    printf("%s\n", bill);
    return 0;
}