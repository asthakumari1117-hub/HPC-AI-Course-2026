#include <stdio.h>

int safeEvaluate(int a, int b) {
    int step1 = a * 2; // Explicit step 1
    int step2 = b + 3; // Explicit step 2
    return step1 + step2;
}

int main() {
    int x = 4, y = 5;
    printf("Safe Evaluated Result: %d\n", safeEvaluate(x, y));
    return 0;
}