#include <stdio.h>

int funcA() { printf("Evaluated A\n"); return 1; }
int funcB() { printf("Evaluated B\n"); return 2; }

int sum(int x, int y) {
    return x + y;
}

int main() {
    // All arguments evaluated before function body is entered
    int total = sum(funcA(), funcB());
    printf("Total: %d\n", total);
    return 0;
}