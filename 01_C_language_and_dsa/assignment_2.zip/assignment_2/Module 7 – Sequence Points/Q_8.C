#include <stdio.h>

int main() {
    int i = 5;

    // UNDEFINED BEHAVIOR: Modifying 'i' multiple times without an intervening sequence point
    // int result = i++ + ++i; // DON'T DO THIS
    
    printf("Multiple modifications of a variable in a single expression cause undefined behavior.\n");
    return 0;
}