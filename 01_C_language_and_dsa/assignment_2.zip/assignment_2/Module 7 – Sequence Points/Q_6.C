#include <stdio.h>

int main() {
    int i = 1, j;

    // Comma operator forces sequence point: left evaluated first completely
    j = (i++, i + 5);

    printf("i: %d, j: %d\n", i, j);
    return 0;
}