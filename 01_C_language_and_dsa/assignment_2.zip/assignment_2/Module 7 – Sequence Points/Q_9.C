#include <stdio.h>

int main() {
    int i = 5;

    // Unsafe: int result = i++ + ++i;
    
    // Safe rewrite:
    int val1 = i;
    i++;
    i++;
    int val2 = i;
    int safeResult = val1 + val2;

    printf("Safe Result: %d, Final i: %d\n", safeResult, i);
    return 0;
}