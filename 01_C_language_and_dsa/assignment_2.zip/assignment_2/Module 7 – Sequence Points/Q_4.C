#include <stdio.h>

int main() {
    int a = 5;

    // Left condition true; right condition is skipped
    if (a == 5 || ++a == 6) {
        printf("Logical OR short-circuited. a is still: %d\n", a);
    }

    return 0;
}