#include <stdio.h>

int main() {
    int i = 1;
    printf("i++ evaluates to: %d\n", i++); // Output 1, then incremented
    printf("Value of i now: %d\n", i);     // Output 2
    printf("++i evaluates to: %d\n", ++i); // Incremented then Output 3
    return 0;
}