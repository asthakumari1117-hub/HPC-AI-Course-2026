#include <stdio.h>

int main() {
    int a = 5; // Semicolon is a sequence point
    a = a + 2; // Previous side-effects completed before this point
    printf("a = %d\n", a);
    return 0;
}