#include <stdio.h>

int main() {
    int x = 0;
    
    // Left side evaluated first; sequence point exists before right side evaluation
    if (x != 0 && (10 / x > 1)) {
        printf("Inside if\n");
    } else {
        printf("Short-circuit prevented division by zero!\n");
    }

    return 0;
}