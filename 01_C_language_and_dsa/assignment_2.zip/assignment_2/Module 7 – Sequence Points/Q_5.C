#include <stdio.h>

int main() {
    int x = 10;
    
    // Sequence point exists after condition evaluation
    int result = (x > 5) ? (++x) : (--x);

    printf("Result: %d, x: %d\n", result, x);
    return 0;
}