#include <stdio.h>

int main() {
    int choice = 1;
    double a = 12, b = 4;

    printf("1. Add\n2. Subtract\n3. Multiply\n4. Divide\nChoice: %d\n", choice);

    switch (choice) {
        case 1: printf("Result: %.2f\n", a + b); break;
        case 2: printf("Result: %.2f\n", a - b); break;
        case 3: printf("Result: %.2f\n", a * b); break;
        case 4: printf("Result: %.2f\n", a / b); break;
        default: printf("Invalid Choice\n");
    }

    return 0;
}