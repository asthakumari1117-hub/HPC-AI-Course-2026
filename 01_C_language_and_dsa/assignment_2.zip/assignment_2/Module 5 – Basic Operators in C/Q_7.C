#include <stdio.h>

int main() {
    int a = 5, b = 5;

    printf("Initial a = 5, b = 5\n");
    printf("Pre-decrement  (--a): %d\n", --a);
    printf("Post-decrement (b--): %d\n", b--);
    printf("After post-decrement b: %d\n", b);

    return 0;
}