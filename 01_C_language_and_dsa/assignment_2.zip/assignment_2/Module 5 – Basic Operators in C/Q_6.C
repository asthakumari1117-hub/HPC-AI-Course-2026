#include <stdio.h>

int main() {
    int a = 5, b = 5;

    printf("Initial a = 5, b = 5\n");
    printf("Pre-increment  (++a): %d\n", ++a);
    printf("Post-increment (b++): %d\n", b++);
    printf("After post-increment b: %d\n", b);

    return 0;
}