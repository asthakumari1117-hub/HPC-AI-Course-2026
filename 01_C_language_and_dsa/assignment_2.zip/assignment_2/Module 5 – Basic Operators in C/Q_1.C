#include <stdio.h>

int main() {
    double a = 20, b = 5;

    printf("Add      : %.2f\n", a + b);
    printf("Subtract : %.2f\n", a - b);
    printf("Multiply : %.2f\n", a * b);
    printf("Divide   : %.2f\n", a / b);
    printf("Modulus  : %d\n", (int)a % (int)b);

    return 0;
}