#include <stdio.h>

int main() {
    int result = 10 + 2 * 5 - 8 / 4 + (3 * 2);
    // 10 + 10 - 2 + 6 = 24
    printf("Result of 10 + 2 * 5 - 8 / 4 + (3 * 2) = %d\n", result);
    return 0;
}