#include <stdio.h>

int main() {
    int mathMarks = 75, physicsMarks = 65, total = 140;

    if (mathMarks >= 60 && physicsMarks >= 50 && total >= 130) {
        printf("Eligible for Admission.\n");
    } else {
        printf("Not Eligible.\n");
    }

    return 0;
}