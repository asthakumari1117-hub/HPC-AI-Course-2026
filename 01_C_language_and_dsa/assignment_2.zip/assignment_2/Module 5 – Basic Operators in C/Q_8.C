#include <stdio.h>

int main() {
    int x = 45, y = 80;
    int max = (x > y) ? x : y;

    printf("Maximum between %d and %d is: %d\n", x, y, max);
    return 0;
}