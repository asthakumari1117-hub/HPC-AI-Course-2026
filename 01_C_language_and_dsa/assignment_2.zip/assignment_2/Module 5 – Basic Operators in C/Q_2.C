#include <stdio.h>

int main() {
    int a = 15, b = 25, c = 20;

    if (a >= b && a >= c) printf("Largest: %d\n", a);
    else if (b >= a && b >= c) printf("Largest: %d\n", b);
    else printf("Largest: %d\n", c);

    return 0;
}